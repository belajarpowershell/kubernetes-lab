In this Lab setup The Hyper V host server specifications are as follows

1. Interl i7-8700 3.2GHz CPU
2. 32GB of Memory
3. At least 1 Terabytes of Hard Disk

As a reference with all the Virtual Machines Running the following was the utilization
1. CPU <50% utilization
2. Memory ~ 64% 

This is to provide a perspective on the Host CPU specifications for your Lab setup.
